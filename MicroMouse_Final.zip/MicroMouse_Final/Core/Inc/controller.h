/*
 * controller.h
 */

#ifndef INC_CONTROLLER_H_
#define INC_CONTROLLER_H_

#include "main.h"

void move(int8_t n);
void turn(int8_t n);

#endif /* INC_CONTROLLER_H_ */